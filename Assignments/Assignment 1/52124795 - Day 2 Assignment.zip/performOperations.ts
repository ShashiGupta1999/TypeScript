/* 2. Write a TypeScript program that declares variables of the following data types: number, string, boolean, and undefined. Assign values to
     them and perform basic operations. */

     var numberVar:number;
      numberVar =10;
     var numberVariableSum = numberVar + 5;
     console.log("number Variable Sum = " + numberVariableSum);

     var stringVariable = "Shashi";
     var stringVariableConcatenate = stringVariable + " "+ "Gupta";
     console.log("Concatenate String = " + stringVariableConcatenate)

     var booleanVariable = true;
     var booleanOperation = booleanVariable && false;
     console.log("Boolean Operation = " + booleanOperation)

     var undefinedVariable:undefined;
     var isUndefined = (undefinedVariable === undefined);
     console.log("Is it Undefined =" + isUndefined)

