/* 1. Write a TypeScript program that declares a variable `name` and assigns it a string value. Also declare a variable `age` and assign it a
number value. Finally print the values of name and age. */
var name1 = "Shashi";
var age = 24;
console.log("name1 = " + name1 + "  " + "Age =" + age);
